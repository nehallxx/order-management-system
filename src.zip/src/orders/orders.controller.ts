import { Body, Controller, Get, Param, Post, Put } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Controller('api/orders')
export class OrdersController {
  constructor(private readonly prisma: PrismaService) {}

  @Post()
  async createOrder(@Body() data: { userId: number }) {
    const cartItems = await this.prisma.cartItem.findMany({
      where: { userId: data.userId },
      include: { product: true },
    });

    const order = await this.prisma.order.create({
      data: {
        userId: data.userId,
        status: 'PENDING',
        orderItems: {
          create: cartItems.map(item => ({
            productId: item.productId,
            quantity: item.quantity,
          })),
        },
      },
    });

    await this.prisma.cartItem.deleteMany({
      where: { userId: data.userId },
    });

    return order;
  }

  @Get(':orderId')
  async getOrder(@Param('orderId') orderId: number) {
    return this.prisma.order.findUnique({
      where: { orderId: orderId },
      include: { orderItems: { include: { product: true } } },
    });
  }

  @Put(':orderId/status')
  async updateOrderStatus(@Param('orderId') orderId: number, @Body() data: { status: string }) {
    return this.prisma.order.update({
      where: { orderId: orderId },
      data: { status: data.status },
    });
  }

  @Post('apply-coupon')
  async applyCoupon(@Body() data: { orderId: number; couponCode: string }) {
    const discount = await validateAndCalculateDiscount(data.couponCode);

    return this.prisma.order.update({
      where: { orderId: data.orderId },
      data: { discount: discount } as any, 
    });
  }
}

async function validateAndCalculateDiscount(couponCode: string) {
  return 10; 
}
