import { Injectable, INestApplication, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit {
  async onModuleInit() {
    await this.$connect();
  }

  async enableShutdownHooks(app: INestApplication) {
    // Use intersection type to augment the $on method
    (this as PrismaClient & { $on(event: 'beforeExit', callback: () => void): void }).$on('beforeExit', async () => {
      await app.close();
    });
  }
}
