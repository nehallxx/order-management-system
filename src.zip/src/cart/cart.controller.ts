import { Body, Controller, Delete, Get, Param, Post, Put } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Controller('api/cart')
export class CartController {
  constructor(private readonly prisma: PrismaService) {}

  @Post('add')
  async addToCart(@Body() data: { userId: number; productId: number; quantity: number }) {
    const cartItem = await this.prisma.cartItem.findFirst({
      where: { userId: data.userId, productId: data.productId },
    });

    if (cartItem) {
      return this.prisma.cartItem.update({
        where: { cartItemId: cartItem.cartItemId },
        data: { quantity: cartItem.quantity + data.quantity },
      });
    } else {
      return this.prisma.cartItem.create({
        data: {
          userId: data.userId,
          productId: data.productId,
          quantity: data.quantity,
        },
      });
    }
  }

  @Get(':userId')
  async getCart(@Param('userId') userId: number) {
    return this.prisma.cartItem.findMany({
      where: { userId: userId },
      include: { product: true },
    });
  }

  @Put('update')
  async updateCart(@Body() data: { cartItemId: number; quantity: number }) {
    return this.prisma.cartItem.update({
      where: { cartItemId: data.cartItemId },
      data: { quantity: data.quantity },
    });
  }

  @Delete('remove')
  async removeFromCart(@Body() data: { cartItemId: number }) {
    return this.prisma.cartItem.delete({
      where: { cartItemId: data.cartItemId },
    });
  }
}
