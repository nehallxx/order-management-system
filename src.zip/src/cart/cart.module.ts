import { Module } from '@nestjs/common';
import { CartController } from './cart.controller';
import { PrismaService } from '../prisma.service';

@Module({
  imports: [],
  controllers: [CartController],
  providers: [PrismaService],
})
export class CartModule {}


