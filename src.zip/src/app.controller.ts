import { Controller, Get } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Controller()
export class AppController {
  constructor(private readonly prismaService: PrismaService) {} // mak sure param name matches serv name

  @Get()
  async getHello(): Promise<string> {
    const users = await this.prismaService.user.findMany();

    return `Hello, found ${users.length} users.`;
  }
}
