import { Controller, Get, Param } from '@nestjs/common';
import { PrismaService } from '../prisma.service';

@Controller('api/users')
export class UsersController {
  constructor(private readonly prisma: PrismaService) {}

  @Get(':userId/orders')
  async getOrderHistory(@Param('userId') userId: number) {
    return this.prisma.order.findMany({
      where: { userId: userId },
      include: { orderItems: { include: { product: true } } },
    });
  }
}
