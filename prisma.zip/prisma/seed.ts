import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  await prisma.user.createMany({
    data: [
      { name: 'Nehal Khaled', email: 'nehal.k@mail.com', password: 'pass123', address: '123 St' },
      { name: 'Khaled Ibrahim', email: 'khaled.i@mail.com', password: 'pass1234', address: '456 St' },
    ],
  });

  await prisma.product.createMany({
    data: [
      { name: 'Product A', description: 'Descrption for A', price: 10.0, stock: 100 },
      { name: 'Product B', description: 'Descrption for B', price: 15.0, stock: 50 },
    ],
  });
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
